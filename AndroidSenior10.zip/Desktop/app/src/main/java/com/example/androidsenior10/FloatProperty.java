package com.example.androidsenior10;

import android.app.Service;

public class FloatProperty extends Service {
}
